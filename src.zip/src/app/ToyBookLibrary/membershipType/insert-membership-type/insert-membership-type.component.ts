import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insert-membership-type',
  templateUrl: './insert-membership-type.component.html',
  styleUrls: ['./insert-membership-type.component.css']
})
export class InsertMembershipTypeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
