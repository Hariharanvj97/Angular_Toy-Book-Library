import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-membership-type',
  templateUrl: './view-membership-type.component.html',
  styleUrls: ['./view-membership-type.component.css']
})
export class ViewMembershipTypeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
