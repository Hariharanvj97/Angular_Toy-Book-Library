import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-membership-type',
  templateUrl: './update-membership-type.component.html',
  styleUrls: ['./update-membership-type.component.css']
})
export class UpdateMembershipTypeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
