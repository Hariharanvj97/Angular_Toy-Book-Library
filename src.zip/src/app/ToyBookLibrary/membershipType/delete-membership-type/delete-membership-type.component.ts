import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-membership-type',
  templateUrl: './delete-membership-type.component.html',
  styleUrls: ['./delete-membership-type.component.css']
})
export class DeleteMembershipTypeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
