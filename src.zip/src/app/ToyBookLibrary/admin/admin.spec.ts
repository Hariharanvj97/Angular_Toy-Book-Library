import { Admin } from './admin.module';

describe('Admin', () => {
  it('should create an instance', () => {
    expect(new Admin()).toBeTruthy();
  });
});
