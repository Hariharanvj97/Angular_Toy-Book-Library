import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../../admin.service';
import { Admin } from '../admin.module';

@Component({
  selector: 'app-update-admin',
  templateUrl: './update-admin.component.html',
  styleUrls: ['./update-admin.component.css']
})
export class UpdateAdminComponent implements OnInit {
  adminForm: FormGroup;
  constructor(private fb: FormBuilder, private service:AdminService, private router:Router) {}

  ngOnInit(): void {
    alert('UpdateAdminComponent');
    this.adminForm = this.fb.group({
      adminId: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', Validators.required],
      mobile: ['', Validators.required],
      address: ['', Validators.required],
      email: ['', Validators.required],
      gender:['', Validators.required]   
    });

     this.service['getAdminById'](+localStorage.getItem("editAdminId"))
      .subscribe( data => {
        this.adminForm.setValue(data);
      });
  }
  updateAdmin() {
    //this.submitted = true;
    if (this.adminForm.invalid) {
      return;
    }

    let admin:Admin = new Admin(this.adminForm.controls['adminId'].value, 
      this.adminForm.controls['username'].value, 
      this.adminForm.controls['password'].value, 
      this.adminForm.controls['mobile'].value,
      this.adminForm.controls['address'].value,
      this.adminForm.controls['email'].value,
      this.adminForm.controls['gender'].value);

    this.service.updateAdmin(admin)
      //.pipe(first())
      .subscribe(
        data => {
          this.router.navigate(['viewadmin']);
        },
        error => {
          alert(error);
        });
  }

}


// import { Component, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { Router } from '@angular/router';
// import { Address } from '../model/address';
// import { Student } from '../model/student';
// import { StudentService } from '../student.service';

// @Component({
//   selector: 'app-edit-student',
//   templateUrl: './edit-student.component.html',
//   styleUrls: ['./edit-student.component.css']
// })
// export class EditStudentComponent implements OnInit {
//   public studentForm: FormGroup;
//   constructor(private fb: FormBuilder, private service: StudentService, private router: Router) {
//   }

//   ngOnInit() {
//     alert('EditStudentComponent');
//     //if(localStorage.getItem("username")!=null){
//     // if (true) { 
//     // let studentId = localStorage.getItem("editStudentId");
//     // if (!studentId) {
//     //   alert("Invalid action.")
//     //   this.router.navigate(['list-students']);
//     //   return;
//     // }

//     this.studentForm = this.fb.group({
//       studentId: ['', Validators.required],
//       studentName: ['', Validators.required],
//       score: ['', Validators.required],
//       city: ['', Validators.required],
//       state: ['', Validators.required],
//       pin: ['', Validators.required],
//     });

//     this.service.getStudentById(+localStorage.getItem("editStudentId"))
//       .subscribe( data => {
//         this.studentForm.setValue(data);
//       });
//     //}
//     // else
//     //     this.router.navigate(['/login']);
//   }

//   updateStudent() {
//     //this.submitted = true;
//     if (this.studentForm.invalid) {
//       return;
//     }
//     let address:Address = new Address(this.studentForm.controls.city.value, 
//       this.studentForm.controls.state.value, this.studentForm.controls.pin.value);

//     let student:Student = new Student(this.studentForm.controls.studentId.value, 
//       this.studentForm.controls.studentName.value, 
//       this.studentForm.controls.score.value, address);

//     this.service.updateStudent(student)
//       //.pipe(first())
//       .subscribe(
//         data => {
//           this.router.navigate(['list-students']);
//         },
//         error => {
//           alert(error);
//         });
//   }
// }

