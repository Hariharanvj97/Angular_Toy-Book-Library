import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './ToyBookLibrary/login/login.component';
import { InsertAdminComponent } from './ToyBookLibrary/admin/insert-admin/insert-admin.component';
import { DeleteAdminComponent } from './ToyBookLibrary/admin/delete-admin/delete-admin.component';
import { UpdateAdminComponent } from './ToyBookLibrary/admin/update-admin/update-admin.component';
import { ViewAdminComponent } from './ToyBookLibrary/admin/view-admin/view-admin.component';
import { ViewMembershipTypeComponent } from './ToyBookLibrary/membershipType/view-membership-type/view-membership-type.component';
import { DeleteMembershipTypeComponent } from './ToyBookLibrary/membershipType/delete-membership-type/delete-membership-type.component';
import { InsertMembershipTypeComponent } from './ToyBookLibrary/membershipType/insert-membership-type/insert-membership-type.component';
import { UpdateMembershipTypeComponent } from './ToyBookLibrary/membershipType/update-membership-type/update-membership-type.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminService } from './ToyBookLibrary/admin.service';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    InsertAdminComponent,
    DeleteAdminComponent,
    UpdateAdminComponent,
    ViewAdminComponent,
    ViewMembershipTypeComponent,
    DeleteMembershipTypeComponent,
    InsertMembershipTypeComponent,
    UpdateMembershipTypeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [AdminService],
  bootstrap: [AppComponent]
})
export class AppModule { }
