import { Component } from '@angular/core';
import { AdminService } from './ToyBookLibrary/admin.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [AdminService]
})
export class AppComponent {
  title = 'ToyBookLibraryApp';
  admins!: any[];
    constructor(private _adminService: AdminService) {}
      ngOnInit() {
        //this.books = this._bookService.getBooks();
    }
}
